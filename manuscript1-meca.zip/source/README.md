## Quarto Manuscript

This is the repository for generating the Quarto manuscript from the study: *Everything, altogether, all at once: Addressing data challenges when measuring speech intelligibility through entropy scores*

